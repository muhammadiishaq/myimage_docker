<?php


echo "Hello";

echo print_r($_ENV);

?>
